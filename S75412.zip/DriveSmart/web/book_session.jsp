<%-- 
    Document   : book_session
    Created on : 16 Jun 2026, 3:39:29 PM
    Author     : MP2-4
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Book Session</title>
    </head>
    <body>
        <h2>Form</h2>
        <form action="BookSessionServlet" method="POST">
          
            Student Name:<input type="text" id="name" name="name" required><br><br>
            Branch Location:<input type="text" id="branch" name="branch" required><br><br>
            Lesson Type:<input type="text" id="type" name="type" required><br><br>
   
    </body>
</html>
