/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.DAO;

import com.bean.SessionBean;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Base64;
import java.sql.*;
import java.util.*;


public class SessionDAO {
    
    //JDBC connection to drivesmart_db database
    private Connection getConnection() throws Exception{
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/drivesmart_db", "root", "");
    }
    
    //Execute SQL INSERT to save new training booking
    public boolean bookSession(SessionBean session){
        try (Connection conn = getConnection()){
            String sql =
            "INSERT INTO training_sessions (session_id, student_name, branch_location, lesson_type, status) VALUES(?, ?, ?, ?, ?)";
            PreparedStatement myPS = conn.prepareStatement(sql);
            myPS.setInt(1, session.getSession_id());
            myPS.setString(2, session.getStudent_name());
            myPS.setString(3, session.getBranch_location());
            myPS.setString(4, session.getLesson_type());
            myPS.setString(5, session.getStatus());
            
            return myPS.executeUpdate() >0;
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }
    
    //retrieve
    public List<SessionBean> getAllSessions() throws SQLException{
        List<SessionBean> list = new ArrayList<>();
        String sql = "SELECT*FROM training_sessions ORDER BY branch_location ASC";
            
        try(Connection conn = getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)){
            
            //iterate over the result set
            while (rs.next()){
                list.add(new SessionBean(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("location"),
                        rs.getString("lesson"),
                        rs.getString("status")
                ));
                
            }
            return list; 
        }
    }
    
    //delete
    public void deleteProduct(int id) throws SQLException{
        String sql = "DELETE FROM sessionBean WHERE id=?";
        
        try(Connection conn = getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)){
            
            ps.executeUpdate();
        }
    }
}
